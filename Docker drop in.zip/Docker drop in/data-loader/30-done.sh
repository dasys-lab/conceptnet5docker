touch /data/conceptnet/psql/done
